
package guia4;

import javax.swing.*;
import java.awt.Color;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;

public class Robot extends JFrame {

    private int segundosRestantes;
    private Timer timer;
    private Stack<Integer> tiempos = new Stack<>();
    private Stack<String> tareas = new Stack<>();
    private Stack<String> siguientesTareas = new Stack<>();
    private Stack<Integer> siguientesTiempos = new Stack<>();
    private StringBuilder tareasPendientes = new StringBuilder();
    private StringBuilder tiempoPendiente = new StringBuilder();
    private boolean primeraTarea = true;

    public Robot() {
        initComponents();
        getContentPane().setBackground(new Color(1, 1, 1));
    }

    public void iniciarPrograma() {
        int seg = tiempos.peek();
        tareaEjecutandose.setText(tareas.peek());
        reportTiempo.setText(tiempoPendiente + "\n" + tareas.peek() + ": " + seg + " seg.");
        iniciarProgreso(seg);
        timer = new Timer();
        timer.schedule(new Recordatorio(this), seg * 1000);
    }

    public void iniciarProgreso(int segundos) {
        progresoTarea.setMaximum(segundos);
        segundosRestantes = segundos;
        TimerTask tarea = new TimerTask() {
            @Override
            public void run() {
                if (segundosRestantes > 0) {
                    int progresoActual = segundos - segundosRestantes;
                    progresoTarea.setValue(progresoActual);
                    numeroProgreso.setText("Ejecutando... " + segundosRestantes);
                    segundosRestantes--;
                } else {
                    cancel();
                }
            }
        };
        Timer timer = new Timer();
        timer.schedule(tarea, 0, 1000);
    }

    class Recordatorio extends TimerTask {
        Robot ejecutable;
        public Recordatorio(Robot ejecutable) {
            this.ejecutable = ejecutable;
        }
        @Override
        public void run() {
            ejecutable.timer.cancel();
            if (!ejecutable.siguientesTareas.empty()) {
                ejecutable.tareas.pop();
                ejecutable.tiempos.pop();
                ejecutable.tareas.push(ejecutable.siguientesTareas.pop());
                ejecutable.tiempos.push(ejecutable.siguientesTiempos.pop());
            } else {
                if (!ejecutable.primeraTarea) {
                    ejecutable.tareas.pop();
                    ejecutable.tiempos.pop();
                } else {
                    ejecutable.tareas.remove(0);
                    ejecutable.tiempos.remove(0);
                }
            }
            if (!ejecutable.tareas.empty()) {
                ejecutable.iniciarPrograma();
                ejecutable.primeraTarea = false;
            } else {
                ejecutable.tareaEjecutandose.setText(" ");
                ejecutable.primeraTarea = true;
                ejecutable.progresoTarea.setValue(0);
                ejecutable.numeroProgreso.setText("Listo");
            }
        }
    }

    public void modificarTarea(int tiempo, String tarea) {
        if (primeraTarea) {
            tareas.push(tarea);
            tiempos.push(tiempo);
        } else {
            siguientesTareas.push(tarea);
            siguientesTiempos.push(tiempo);
        }

        tareasPendientes.append("\n").append(tarea).append(": ").append(tiempo).append(" seg.");
        reportTarea.setText(tareasPendientes.toString());

        if (tareas.size() == 1) {
            iniciarPrograma();
            primeraTarea = true;
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        canvas1 = new java.awt.Canvas();
        jMenu1 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        asignaTiempo = new javax.swing.JTextField();
        asignaTarea = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        agregaWork = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tareaEjecutandose = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        numeroProgreso1 = new javax.swing.JLabel();
        progresoTarea = new javax.swing.JProgressBar();
        numeroProgreso = new javax.swing.JLabel();
        numeroProgreso2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        reportTarea = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        reportTiempo = new javax.swing.JTextArea();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setForeground(new java.awt.Color(102, 102, 102));

        asignaTiempo.setBackground(new java.awt.Color(51, 51, 51));
        asignaTiempo.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        asignaTiempo.setForeground(new java.awt.Color(255, 255, 255));
        asignaTiempo.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        asignaTarea.setBackground(new java.awt.Color(51, 51, 51));
        asignaTarea.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        asignaTarea.setForeground(new java.awt.Color(255, 255, 255));
        asignaTarea.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel1.setFont(new java.awt.Font("Hack Nerd Font Propo", 3, 16)); // NOI18N
        jLabel1.setText("Duracion:");

        jLabel2.setFont(new java.awt.Font("Hack Nerd Font Propo", 3, 16)); // NOI18N
        jLabel2.setText("Tarea:");

        agregaWork.setBackground(new java.awt.Color(0, 153, 153));
        agregaWork.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        agregaWork.setForeground(new java.awt.Color(255, 51, 51));
        agregaWork.setText("AGREGAR");
        agregaWork.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        agregaWork.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregaWorkActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Hack Nerd Font Propo", 3, 16)); // NOI18N
        jLabel5.setText("Tarea Resgistrada");

        jScrollPane1.setHorizontalScrollBar(null);

        tareaEjecutandose.setBackground(new java.awt.Color(51, 51, 51));
        tareaEjecutandose.setColumns(20);
        tareaEjecutandose.setForeground(new java.awt.Color(255, 255, 255));
        tareaEjecutandose.setRows(5);
        jScrollPane1.setViewportView(tareaEjecutandose);

        jLabel6.setFont(new java.awt.Font("Arial Black", 3, 16)); // NOI18N
        jLabel6.setText("EJECUTANDOSE");

        numeroProgreso1.setFont(new java.awt.Font("Hack Nerd Font Propo", 3, 15)); // NOI18N
        numeroProgreso1.setText("Tarea ejecutanse:");

        progresoTarea.setBackground(new java.awt.Color(0, 0, 0));
        progresoTarea.setForeground(new java.awt.Color(255, 153, 0));

        numeroProgreso.setFont(new java.awt.Font("Arial Black", 3, 15)); // NOI18N
        numeroProgreso.setText("Esperando...");

        numeroProgreso2.setFont(new java.awt.Font("Arial Black", 3, 15)); // NOI18N
        numeroProgreso2.setText("PROGRESO");

        jLabel3.setFont(new java.awt.Font("Hack Nerd Font Propo", 3, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 0, 153));
        jLabel3.setText("Tareas");

        jLabel7.setFont(new java.awt.Font("Hack Nerd Font Propo", 3, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("REGISTRO:");

        jLabel4.setFont(new java.awt.Font("Hack Nerd Font Propo", 3, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 0, 153));
        jLabel4.setText("Ejecutadas");

        reportTarea.setBackground(new java.awt.Color(51, 51, 51));
        reportTarea.setColumns(20);
        reportTarea.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        reportTarea.setForeground(new java.awt.Color(255, 255, 255));
        reportTarea.setRows(5);
        jScrollPane3.setViewportView(reportTarea);

        reportTiempo.setBackground(new java.awt.Color(51, 51, 51));
        reportTiempo.setColumns(20);
        reportTiempo.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        reportTiempo.setRows(5);
        jScrollPane2.setViewportView(reportTiempo);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(progresoTarea, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(179, 179, 179)
                        .addComponent(numeroProgreso)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(43, 43, 43)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(asignaTiempo, javax.swing.GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE)
                                    .addComponent(asignaTarea)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(130, 130, 130)
                                        .addComponent(agregaWork, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(numeroProgreso2))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(214, 214, 214)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(numeroProgreso1)
                        .addGap(119, 119, 119)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(38, 38, 38)
                        .addComponent(jLabel3)
                        .addGap(24, 24, 24)))
                .addGap(37, 37, 37))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(223, 223, 223)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(167, 167, 167)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(82, 82, 82))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 76, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(asignaTarea, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)
                        .addComponent(asignaTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(agregaWork, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(numeroProgreso1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addComponent(numeroProgreso2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2)
                            .addComponent(jScrollPane3))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(progresoTarea, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(numeroProgreso)
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void agregaWorkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregaWorkActionPerformed
    String tiempoTexto = asignaTiempo.getText();
    int tiempo = Integer.parseInt(tiempoTexto);
    String tareaTexto = asignaTarea.getText();
    modificarTarea  (tiempo, tareaTexto);
    asignaTarea.setText("");
    asignaTiempo.setText("");
    }//GEN-LAST:event_agregaWorkActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Robot().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton agregaWork;
    private javax.swing.JTextField asignaTarea;
    private javax.swing.JTextField asignaTiempo;
    private java.awt.Canvas canvas1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel numeroProgreso;
    private javax.swing.JLabel numeroProgreso1;
    private javax.swing.JLabel numeroProgreso2;
    private javax.swing.JProgressBar progresoTarea;
    private javax.swing.JTextArea reportTarea;
    private javax.swing.JTextArea reportTiempo;
    private javax.swing.JTextArea tareaEjecutandose;
    // End of variables declaration//GEN-END:variables
}
