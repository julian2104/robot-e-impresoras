package guia4;

import java.util.Scanner;

public class Guia4 {

    public static void main(String[] args) {
        Scanner ingreso = new Scanner(System.in);
        Impresora fotocopia = new Impresora();
        Robot meca = new Robot();

        int opc;
        do {
            mostrarMenu();
            opc = ingreso.nextInt();
            switch (opc) {
                case 1:
                    fotocopia.setVisible(true);
                    break;
                case 2:
                    meca.setVisible(true);
                    break;
                case 3:
                    System.out.println("Hasta la próxima!");
                    break;
                default:
                    System.out.println("Opción no válida, intente de nuevo.");
            }
        } while (opc != 3);
    }

    public static void mostrarMenu() {
        System.out.println("elige una opcion: \n 1. Impresora. \n 2. Simulacion Robot. \n 3. Salir.");
    }
}